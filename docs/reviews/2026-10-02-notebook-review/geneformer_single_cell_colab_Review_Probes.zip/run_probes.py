"""Review probes for tutorials/geneformer_single_cell_colab.ipynb (Notebook Review Framework v1, prefix GF).

CPU-only direct execution. The install cell runs with DIMER_NOTEBOOK_CI_PREINSTALLED=1 (no pip), so the
environment is the reviewer's conda env (torch 2.13.0+cpu, transformers 4.57.6, safetensors 0.8.0,
huggingface-hub 0.36.2, numpy 2.5.3), NOT the notebook's pins (torch 2.14.0). This is not a Colab run.

Usage: python run_probes.py <repo_worktree> <work_dir> <out_dir>
"""
from __future__ import annotations

import contextlib
import hashlib
import io
import json
import os
import re
import subprocess
import sys
import time
import traceback
import types
from pathlib import Path

REPO = Path(sys.argv[1]).resolve()
WORK = Path(sys.argv[2]).resolve()
OUT = Path(sys.argv[3]).resolve()
NB_PATH = REPO / "tutorials" / "geneformer_single_cell_colab.ipynb"
RESULTS: dict = {"env": {}, "probes": {}}


def save():
    (OUT / "results.json").write_text(json.dumps(RESULTS, indent=1, default=str), encoding="utf-8")


def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


# ---- source manifest
inspected = [
    "tutorials/geneformer_single_cell_colab.ipynb", "tutorials/README.md", "README.md", "STATUS.md",
    "docs/release-verification.md", "docs/WEIGHTS.md", "MODEL_CARD.md", "tools/build_notebook.py",
    "tools/notebook_template.py", "tools/validate_release_assets.py",
    "src/geneformer_single_cell_pipeline/pipeline.py", "src/geneformer_single_cell_pipeline/samples.py",
    "src/geneformer_single_cell_pipeline/metrics.py",
]
(OUT / "source_manifest.json").write_text(
    json.dumps({p: sha(REPO / p) for p in inspected}, indent=1), encoding="utf-8")

import platform  # noqa: E402

RESULTS["env"] = {"python": platform.python_version(), "platform": platform.platform()}
nb = json.loads(NB_PATH.read_text(encoding="utf-8"))
cells = nb["cells"]
code_idx = [i for i, c in enumerate(cells) if c["cell_type"] == "code"]
src = {i: "".join(c["source"]) for i, c in enumerate(cells)}
md_all = "\n".join(src[i] for i, c in enumerate(cells) if c["cell_type"] == "markdown")

# ---- P1 static structure
p1 = {
    "n_cells": len(cells), "code_cells": code_idx, "n_code": len(code_idx),
    "metadata_dimer": nb["metadata"].get("dimer"),
    "double_brace_in_markdown": [i for i in src if "{{" in src[i] and cells[i]["cell_type"] == "markdown"],
    "form_fields": {i: re.findall(r"^(\w+) = (.+?)  # @param", src[i], re.M) for i in code_idx if "@param" in src[i]},
    "install_cell_pip_into_kernel": "pip', 'install'" in src[3],
    "install_cell_restart_guard": "Restart the runtime" in src[3],
    "uses_uv": "uv venv" in json.dumps(nb),
    "carried_module_lines": {i: src[i].count("\n") + 1 for i in code_idx if cells[i].get("metadata", {}).get("dimer", {}).get("embedded_module")},
    "guided_markers": {k: bool(re.search(k, md_all, re.I)) for k in [
        r"how to use this notebook", r"intended (learner|audience)|who this notebook is for", r"roadmap",
        r"glossary", r"\bpredict(ion)?\b.*before", r"checkpoint", r"troubleshoot", r"infrastructure",
        r"expected result|what to notice|look for", r"conclusion template|your conclusion"]},
    "optional_experiments_rerun_scope": bool(re.search(r"re-?run (cells|sections?|from Section [89])", src[30], re.I)),
}
RESULTS["probes"]["P1_static"] = p1
save()

# ---- P2 generator parity and provenance
p2 = {}
r = subprocess.run([sys.executable, "tools/build_notebook.py", "--check"], cwd=REPO, capture_output=True, text=True)
p2["build_notebook_check_rc"] = r.returncode
p2["build_notebook_check_out"] = (r.stdout + r.stderr)[-600:]
gen = nb["metadata"]["dimer"]["generated_from"]
p2["generated_from_revision"] = gen["revision"]
p2["module_sha256_metadata"] = gen["module_sha256"]
p2["pipeline_py_sha256_head"] = sha(REPO / "src/geneformer_single_cell_pipeline/pipeline.py")
for rev in (gen["revision"], "HEAD"):
    out = subprocess.run(["git", "show", f"{rev}:src/geneformer_single_cell_pipeline/pipeline.py"], cwd=REPO, capture_output=True)
    p2[f"pipeline_py_sha256_at_{rev[:7]}"] = hashlib.sha256(out.stdout).hexdigest()
p2["modules_changed_since_generating_revision"] = subprocess.run(
    ["git", "diff", "--stat", gen["revision"], "HEAD", "--", "src"], cwd=REPO, capture_output=True, text=True).stdout.strip() or "none"
p2["notebook_blob"] = subprocess.run(["git", "rev-parse", "HEAD:tutorials/geneformer_single_cell_colab.ipynb"], cwd=REPO, capture_output=True, text=True).stdout.strip()
RESULTS["probes"]["P2_provenance"] = p2
save()

# ---- execution harness
WORK.mkdir(parents=True, exist_ok=True)
os.chdir(WORK)
os.environ["DIMER_NOTEBOOK_CI_PREINSTALLED"] = "1"
UPLOAD: dict = {"payload": None}
colab = types.ModuleType("google.colab")
files_mod = types.SimpleNamespace(upload=lambda: dict(UPLOAD["payload"] or {}))
colab.files = files_mod
google = types.ModuleType("google")
google.colab = colab
sys.modules.setdefault("google", google)
sys.modules["google.colab"] = colab
NS: dict = {"__name__": "__main__"}


def run_cell(i: int, text: str | None = None, ns: dict | None = None) -> dict:
    ns = NS if ns is None else ns
    buf = io.StringIO()
    t0 = time.perf_counter()
    rec: dict = {"cell": i}
    try:
        with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
            exec(compile(text if text is not None else src[i], f"cell{i}", "exec"), ns)
        rec["ok"] = True
    except BaseException as exc:  # noqa: BLE001
        rec["ok"] = False
        rec["error"] = f"{type(exc).__name__}: {exc}"[:600]
        rec["tb_tail"] = traceback.format_exc()[-800:]
    rec["seconds"] = round(time.perf_counter() - t0, 1)
    rec["stdout_tail"] = buf.getvalue()[-1500:]
    return rec


# ---- P3 default path, all 14 code cells in order
p3 = {"cells": []}
t_all = time.perf_counter()
for i in code_idx:
    rec = run_cell(i)
    p3["cells"].append(rec)
    RESULTS["probes"]["P3_default"] = p3
    save()
    if not rec["ok"]:
        break
p3["total_seconds"] = round(time.perf_counter() - t_all, 1)
p3["all_ok"] = all(c["ok"] for c in p3["cells"]) and len(p3["cells"]) == len(code_idx)
if p3["all_ok"]:
    vr = NS["val_records"]
    p3["embed_val_first8_labels"] = [r["label"] for r in vr[:8]]
    p3["history"] = NS["adapt_result"]["history"]
    p3["test_metrics"] = {k: NS["test_metrics"][k] for k in ("n", "accuracy", "macro_f1", "auroc")}
    p3["val_metrics"] = {k: NS["val_metrics"][k] for k in ("n", "accuracy", "macro_f1", "auroc")}
    p3["baseline_majority"] = {k: NS["baseline_majority"][k] for k in ("accuracy", "macro_f1")}
    p3["baseline_library"] = {k: NS["baseline_library"][k] for k in ("rule", "train_accuracy", "accuracy", "macro_f1", "auroc")}
    p3["trainable"] = [NS["adapt_result"]["trainable_parameters"], NS["adapt_result"]["total_parameters"]]
    p3["outputs"] = sorted(str(p.relative_to(WORK).as_posix()) for p in (WORK / "outputs").rglob("*") if p.is_file())
    p3["result_json_has_batch_size"] = NS["adapt_result"]["batch_size"]
RESULTS["probes"]["P3_default"] = p3
save()


def rerun_from(start_cell: int, edits: dict[int, tuple[str, str]], label: str) -> dict:
    rec = {"label": label, "cells": []}
    for i in [c for c in code_idx if c >= start_cell]:
        text = src[i]
        if i in edits:
            old, new = edits[i]
            assert old in text, (i, old)
            text = text.replace(old, new)
        r = run_cell(i, text)
        rec["cells"].append({k: r[k] for k in ("cell", "ok", "seconds") if k in r} | ({"error": r["error"]} if not r["ok"] else {}))
        if not r["ok"]:
            break
    if all(c["ok"] for c in rec["cells"]):
        rec["history"] = NS["adapt_result"]["history"]
        rec["test_metrics"] = {k: NS["test_metrics"][k] for k in ("n", "accuracy", "macro_f1", "auroc")}
        rec["trainable"] = NS["adapt_result"]["trainable_parameters"]
    return rec


# ---- P4 active learning: the two documented optional experiments, rerun from Section 8 (cell 21)
if p3["all_ok"]:
    p4 = {}
    p4["epochs_2"] = rerun_from(21, {21: ("EPOCHS = 4  #", "EPOCHS = 2  #")}, "EPOCHS=2")
    RESULTS["probes"]["P4_active"] = p4
    save()
    p4["trainable_layers_0"] = rerun_from(21, {21: ("TRAINABLE_LAYERS = 2  #", "TRAINABLE_LAYERS = 0  #")}, "TRAINABLE_LAYERS=0")
    RESULTS["probes"]["P4_active"] = p4
    save()

# ---- P5 BYOD and recovery (validation-level; uses the vocabulary only)
p5 = {}
if "vocabulary" in NS:
    voc = NS["vocabulary"]
    gen_ds = NS["generate_sample_dataset"]
    validate_dataset, split_dataset = NS["validate_dataset"], NS["split_dataset"]
    load_byod, write_csv = NS["load_byod_dataset"], NS["write_dataset_csv"]
    byod_dir = WORK / "byod"
    byod_dir.mkdir(exist_ok=True)

    def cell13_with_upload(name: str, payload: bytes | None) -> dict:
        UPLOAD["payload"] = {} if payload is None else {name: payload}
        return run_cell(13, src[13].replace("USE_BYOD = False  #", "USE_BYOD = True  #"))

    def splits_pass_contract(n_per_class: int, n_classes: int = 2) -> dict:
        recs = []
        base = gen_ds(voc, seed=11, size=max(8, 2 * n_per_class))
        labels = [f"c{k}" for k in range(n_classes)]
        pool = base * ((n_per_class * n_classes) // len(base) + 1)
        for k in range(n_per_class * n_classes):
            recs.append({"id": f"cell{k}", "counts": dict(pool[k]["counts"]), "label": labels[k % n_classes]})
        out = {"n_per_class": n_per_class, "n_classes": n_classes}
        try:
            validate_dataset(recs, vocabulary=voc)
            out["dataset"] = "accepted"
            sp = split_dataset(recs, val_fraction=0.2, test_fraction=0.25, seed=42)
            out["split_sizes"] = {k: len(v) for k, v in sp.items()}
            for part in ("train", "validation", "test"):
                try:
                    validate_dataset(sp[part], vocabulary=voc, classes=labels)
                    out[part] = "accepted"
                except Exception as e:  # noqa: BLE001
                    out[part] = f"{type(e).__name__}: {e}"
        except Exception as e:  # noqa: BLE001
            out["dataset"] = f"{type(e).__name__}: {e}"
        return out

    # stated minimum: 8 records, 3 per class (two classes of 4)
    p5["stated_minimum_8x2cls"] = splits_pass_contract(4)
    p5["3_per_class_x3cls"] = splits_pass_contract(3, 3)
    smallest = None
    for n in range(4, 40):
        o = splits_pass_contract(n)
        if all(o.get(k) == "accepted" for k in ("dataset", "train", "validation", "test")):
            smallest = o
            break
    p5["smallest_two_class_balanced_passing_all_splits"] = smallest

    # round trip of the written template CSV through the BYOD branch of cell 13
    tmpl = WORK / "outputs" / "geneformer_single_cell_sample_dataset.csv"
    if tmpl.is_file():
        r = cell13_with_upload("my_cells.csv", tmpl.read_bytes())
        p5["template_csv_roundtrip_cell13"] = {"ok": r["ok"], "error": r.get("error"), "out": r["stdout_tail"][-700:]}
        p5["template_overwritten_by_byod_records"] = (WORK / "outputs" / "geneformer_single_cell_sample_dataset.csv").is_file() and NS.get("data_source", "").startswith("BYOD")

    # invalid inputs through cell 13
    good = gen_ds(voc, seed=3, size=12)
    mouse = [{"id": r["id"], "counts": {f"ENSMUSG{int(k[4:]):011d}": v for k, v in r["counts"].items()}, "label": r["label"]} for r in good]
    cases = {
        "mouse_ids.json": json.dumps(mouse).encode(),
        "bad_header.csv": b"cell,ENSG00000141510,label\nx,1,a\n",
        "one_class.jsonl": "\n".join(json.dumps({**r, "label": "only"}) for r in good).encode(),
        "cells.h5ad": b"\x89HDF\r\n",
        "non_numeric.csv": b"id,ENSG00000141510,ENSG00000111640,label\nx,abc,2,a\n",
    }
    for name, payload in cases.items():
        r = cell13_with_upload(name, payload)
        p5[f"invalid_{name}"] = {"ok": r["ok"], "error": r.get("error")}
    r = cell13_with_upload("", None)
    p5["upload_cancelled"] = {"ok": r["ok"], "error": r.get("error")}
RESULTS["probes"]["P5_byod"] = p5
save()
print("DONE")
